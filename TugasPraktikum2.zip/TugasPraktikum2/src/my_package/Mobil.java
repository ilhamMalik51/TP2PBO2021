/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
Saya Muhammad Ilham Malik mengerjakan [] dari mata kuliah 
Desain PBO untuk keberkahannNYa maka saya tidak melakukan kecurangan 
seperti yang telah dispesifikasikan.
*/
package my_package;

/**
 *
 * @author Muhammad Ilham Malik
 */
public class Mobil {
    String merk;
    String jenis;
    String warna;
    String plat;
    
    //untuk keperluan instansiasi
    public Mobil(String merk, String jenis, String warna, String plat){
        this.merk = merk;
        this.jenis = jenis;
        this.warna = warna;
        this.plat = plat;
    }
    
    //seluruh metode get
    public String getMerk(){
        return this.merk;
    }
    
    public String getJenis(){
        return this.jenis;
    }
    
    public String getWarna(){
        return this.warna;
    }
    
    public String getPlat(){
        return this.plat;
    }    
}
