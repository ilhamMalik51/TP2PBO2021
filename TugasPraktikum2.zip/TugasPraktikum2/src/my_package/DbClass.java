/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
Saya Muhammad Ilham Malik mengerjakan [] dari mata kuliah 
Desain PBO untuk keberkahannNYa maka saya tidak melakukan kecurangan 
seperti yang telah dispesifikasikan.
*/
package my_package;

import java.sql.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.*;

/**
 *
 * @author Muhammad Ilham Malik
 */
public class DbClass {
    
    JFrame f;
    //deklarasi method dbclass
    public DbClass(String Merk, String Plat, String Warna, String Jenis) throws SQLException
    {
        //koneksi sama seperti select hanya saja ini insert
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/mobilDB", "mobil", "mobil");
        PreparedStatement st = con.prepareStatement("insert into MOBIL (Merk, Plat, Warna, Jenis) values (? , ? , ? , ?) ");
        
        st.setString(1, Merk);
        st.setString(2, Plat);
        st.setString(3, Warna);
        st.setString(4, Jenis);
        
        int a = st.executeUpdate();
        if(a > 0){
            f = new JFrame();
            JOptionPane.showMessageDialog(f,"Submit Data Berhasil!","Alert",JOptionPane.WARNING_MESSAGE);
        }
    }
}
